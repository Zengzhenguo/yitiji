
window.$config = {
  'version': '1.0.6'
}
